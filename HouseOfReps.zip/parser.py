import os,re,sys

def absolute_path():
    THIS_FOLDER = os.path.dirname(os.path.abspath(__file__))
    return THIS_FOLDER

#gets downloaded modules
def get_dirs():
    x=absolute_path()
    temp = os.listdir(x+'/modules')
    modules = list()
    for e in temp:
        if os.path.isfile(e):
            pass#used to pass .DS_Store
                #.DS_Store is used to store attributes of MacOS directories
        else:
            my_file = os.path.join(x+'/modules/', e)
            modules.append(my_file)
    return modules

module_directory = get_dirs()
#translates files into readable dict
def load_files():
    trigger_list = list()
    call_list = list()
    for module in module_directory:
        header = list()
        body = list()    
        filenamelist = list()
        current_dir = list()
        temp = os.listdir(module)
        for ele in temp:
            if ((ele !='.DS_Store') and (('.py' in ele) or ('.OSDA' in ele))):
                current_dir.append(ele)
        for file in current_dir:
            if '.OSDA' in file:
                script = list()
                fi = open(module +'/'+ file,'r')
                for line in fi:
                    script.append(line)
                for i in range(len(script)):
                    if '__BEGIN__' in script[i]:
                        n = 1
                        while '}' not in script[i+n]:
                            header.append(script[i+n])
                            n+=1
                        for line in header:
                            if 'use' in line.lower():
                                regex = r'\b\w+\b'
                                list1=re.findall(regex,line)
                                list1.pop(0)
                                for k in range(len(list1)):
                                    if list1[k] !='py':
                                        filenamelist.append(list1[k])
                                    else:
                                        for x in range(k):
                                            list1.pop(x)
                                        try:
                                            list1.remove('py')
                                            list1.remove('as')
                                        except:
                                            pass
                                        break
                                filename = ''
                                for i in range(len(filenamelist)):
                                    if i+1 != len(filenamelist):
                                        filename = filename + filenamelist[i] + '_'
                                    else:
                                        filename += filenamelist[i]
                                identifier = list1[0]
                                
                                obj = {identifier :filename}
                    if '__FUNCTIONS__' in script[i]:
                        n = 1
                        while '}' not in script[i+n]:
                            body.append(script[i+n])
                            n+=1
                        for ele in body:
                            temp = ele#just a habit
                            pattern= r"^\s+"
                            temp=re.sub(pattern,"",temp)
                            trigger,temp = temp.split(' ',1)
                            trash,temp = temp.split(' ',1)
                            temp, trash = temp.split(';',1)
                            call,func = temp.split('.',1)
                            if call == identifier:
                                call = obj.get(identifier)
                                
                            call = module +'/:'+call + '.' +func
                            call_list.append(call)
                            trigger_list.append(trigger)
    return trigger_list,call_list
                        

triggers,calls = load_files()
#imports functions to parser file
def activate_files(calls=calls,triggers=triggers):
    trigger_to_call = list()
    n=0
    for ele in calls:
        path,file = ele.split(':')
        filecall = file
        trash,filecall = filecall.split('.')
        file,arg = file.split('(')
        sys.path.insert(1, path)
    
        file, function = file.split('.')
        exec('from ' + file +' import ' + function, globals())
        ttc = {triggers[n]:filecall}
        trigger_to_call.append(ttc)
        n+=1
    return trigger_to_call


def call_function(user_input,final_state = activate_files()):
    l = False
    mainvalue =''
    argument = ''
    for word in (user_input.split()):
        if l == False:
            for i in range(len(final_state)):
                    form = str(final_state[i].keys())
                    value = str(final_state[i].values())
                    trash, form = form.split("'",1)
                    form,trash = form.split("'",1)
                    trash, value = value.split("'",1)
                    value,trash = value.split("'",1)
                    if word == form:
                        mainvalue = value
                        l = True
        else:
            argument+=word+ ' '
    mainvalue = mainvalue.replace('x',"'" + argument +"'")
    exec(mainvalue)
    
